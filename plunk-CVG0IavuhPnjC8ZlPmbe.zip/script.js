function initStats() {
            var stats = new Stats();
            stats.setMode(0); // 0: fps, 1: ms
            // Align top-left
            stats.domElement.style.position = 'absolute';
            stats.domElement.style.left = '0px';
            stats.domElement.style.top = '0px';
            document.getElementById("Stats-output").appendChild(stats.domElement);
            return stats;
        }

window.addEventListener("load", function () {

  // main container.
var stats = initStats();
  // Clock
  var clock = new THREE.Clock();

  // Set up uniform.
  var tuniform = {
      iTime: { type: 'f', value: 0.1 },
      iResolution: {type: "v2", value: new THREE.Vector2()}
  };
  tuniform.iResolution.value.x = window.innerHeight; 
  tuniform.iResolution.value.y = window.innerWidth; 

  // Set up our scene.
  var scene = new THREE.Scene();

  var camera = new THREE.PerspectiveCamera(45, window.innerWidth / window.innerHeight, 0.1, 1000);
  camera.position.z = 1000;

  var renderer = new THREE.WebGLRenderer({antialias: true});
  renderer.setClearColor(new THREE.Color(0x000000, 1.0));
  renderer.setSize(window.innerWidth, window.innerHeight);
  renderer.shadowMapEnabled = true;

  document.getElementById("WebGL-output").appendChild(renderer.domElement);

  var mat = new THREE.ShaderMaterial( {
      uniforms: tuniform,
      vertexShader: $('#vertexshader').text(),
      fragmentShader: $('#fragmentshader').text(),
      transparent: true
      //side:THREE.DoubleSide
  } );

  //var tobject = new THREE.Mesh( new THREE.PlaneGeometry(700, 394, 1, 1), mat);
  var tobject = new THREE.Mesh( new THREE.PlaneBufferGeometry (700, 394, 1, 1), mat);

  scene.add(tobject);

  var loop = function loop() {
    stats.update();
    requestAnimationFrame(loop);
    tuniform.iTime.value += clock.getDelta();
    renderer.render(scene, camera);
  };

  loop();

}, false);
